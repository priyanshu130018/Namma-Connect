import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import datetime
import json

from app.core.database import Base, get_db
from app.main import app
from app.models.booking import Booking
from app.models.user import Login, Tourist
from app.models.payment import Payment

TEST_DB_URL = "sqlite:///./test_prod_upgrades.db"
engine = create_engine(TEST_DB_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db():
    app.dependency_overrides[get_db] = override_get_db
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    
    u = Login(email="test.tourist@example.com", full_name="Test Tourist", password="password", role="tourist")
    db.add(u)
    db.commit()
    db.refresh(u)
    
    t = Tourist(user_id=u.id, name="Test Tourist", mobile="9876543210")
    db.add(t)
    db.commit()
    db.refresh(t)
    
    b = Booking(
        id=999,
        tourist_id=t.id,
        booking_type="farm",
        farm_id=1,
        check_in=datetime.date.today(),
        check_out=datetime.date.today() + datetime.timedelta(days=1),
        total_price=150.00,
        status="pending",
        payment_status="unpaid"
    )
    db.add(b)
    db.commit()
    
    yield
    db.close()
    Base.metadata.drop_all(bind=engine)
    app.dependency_overrides.pop(get_db, None)

def test_exceptions_format():
    # Trigger 422 validation exception
    res = client.post("/auth/register", json={"email": "not-an-email"})
    assert res.status_code == 422
    data = res.json()
    assert data["success"] is False
    assert "message" in data

def test_rate_limiting_triggered():
    # Make multiple quick login attempts to trigger 429
    # Limit is 5 per minute
    statuses = []
    for _ in range(7):
        res = client.post("/auth/login", json={"identifier": "test.tourist@example.com", "password": "wrong"}, headers={"x-test-rate-limit": "true"})
        statuses.append(res.status_code)
    
    assert 429 in statuses

def test_media_upload_validation_mime():
    # Test file with unsupported mime type
    files = {"file": ("test.txt", b"some text content", "text/plain")}
    res = client.post("/media/upload", files=files)
    assert res.status_code == 400
    assert res.json()["success"] is False
    assert "Only images and videos are allowed" in res.json()["message"]

def test_media_upload_validation_size():
    # Test file with exceeding size (11MB)
    large_content = b"0" * (11 * 1024 * 1024)
    files = {"file": ("test.jpg", large_content, "image/jpeg")}
    res = client.post("/media/upload", files=files)
    assert res.status_code == 400
    assert res.json()["success"] is False
    assert "exceeds the 10MB limit" in res.json()["message"]

def test_webhook_payment_captured_notes():
    db = TestingSessionLocal()
    booking = db.query(Booking).filter(Booking.id == 999).first()
    assert booking.payment_status == "unpaid"
    
    payload = {
        "event": "payment.captured",
        "payload": {
            "payment": {
                "entity": {
                    "receipt": "receipt_999",
                    "amount": 15000,
                    "currency": "INR",
                    "notes": {
                        "booking_id": 999
                    }
                }
            }
        }
    }
    
    res = client.post("/webhook/razorpay", json=payload)
    assert res.status_code == 200
    assert res.json()["success"] is True
    
    db.refresh(booking)
    assert booking.payment_status == "paid"
    
    payment = db.query(Payment).filter(Payment.booking_id == 999).first()
    assert payment is not None
    assert payment.status == "paid"

def test_webhook_payment_failed():
    db = TestingSessionLocal()
    booking = db.query(Booking).filter(Booking.id == 999).first()
    
    payload = {
        "event": "payment.failed",
        "payload": {
            "payment": {
                "entity": {
                    "receipt": "receipt_999",
                    "amount": 15000,
                    "notes": {
                        "booking_id": 999
                    }
                }
            }
        }
    }
    
    res = client.post("/webhook/razorpay", json=payload)
    assert res.status_code == 200
    
    db.refresh(booking)
    assert booking.payment_status == "failed"
