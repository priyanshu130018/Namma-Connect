import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import datetime

from app.core.database import Base, get_db
from app.main import app
from app.models.booking import Booking
from app.models.user import Login, Tourist
from app.services.email_service import EmailService
from app.services.cloudinary_service import CloudinaryService

TEST_DB_URL = "sqlite:///./test_new_features.db"
engine = create_engine(TEST_DB_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db():
    app.dependency_overrides[get_db] = override_get_db
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    
    u = Login(email="test.tourist@example.com", full_name="Test Tourist", password="password", role="tourist")
    db.add(u)
    db.commit()
    db.refresh(u)
    
    t = Tourist(user_id=u.id, name="Test Tourist", mobile="9876543210")
    db.add(t)
    db.commit()
    db.refresh(t)
    
    b = Booking(
        tourist_id=t.id,
        booking_type="farm",
        farm_id=1,
        check_in=datetime.date.today(),
        check_out=datetime.date.today() + datetime.timedelta(days=1),
        total_price=150.00,
        status="pending",
        payment_status="unpaid"
    )
    db.add(b)
    db.commit()
    
    yield
    db.close()
    Base.metadata.drop_all(bind=engine)
    app.dependency_overrides.pop(get_db, None)

def test_cloudinary_service_mock(monkeypatch):
    monkeypatch.setattr(
        "cloudinary.uploader.upload",
        lambda file, **kwargs: {"secure_url": "https://cloudinary.com/test.jpg", "public_id": "test_id"}
    )
    res = CloudinaryService.upload_image(b"dummyfilebytes")
    assert res["secure_url"] == "https://cloudinary.com/test.jpg"
    assert res["public_id"] == "test_id"

def test_email_service_fallback():
    res = EmailService.send_email("test@example.com", "Test Subject", "Test Body")
    assert res["success"] is True
    assert res.get("mocked") is True

def test_create_payment_order_mock():
    db = TestingSessionLocal()
    booking = db.query(Booking).first()
    res = client.post("/payments/create-order", json={"booking_id": booking.id})
    assert res.status_code == 200
    data = res.json()
    assert "order_id" in data
    assert data["amount"] == 150.00

def test_verify_payment_order_mock():
    db = TestingSessionLocal()
    booking = db.query(Booking).first()
    assert booking.payment_status == "unpaid"
    
    res = client.post("/payments/verify", json={
        "booking_id": booking.id,
        "razorpay_order_id": "order_mock_123",
        "razorpay_payment_id": "pay_mock_123",
        "razorpay_signature": "sig_mock_123"
    })
    assert res.status_code == 200
    assert res.json()["success"] is True
    
    # Reload and check database state
    db.close()
    db2 = TestingSessionLocal()
    booking = db2.query(Booking).first()
    assert booking.payment_status == "paid"
    db2.close()
