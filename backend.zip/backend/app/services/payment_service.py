import razorpay
import logging
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.core.config import settings
from app.models.booking import Booking
from app.models.payment import Payment
from app.services.email_service import EmailService

LOGGER = logging.getLogger(__name__)

# Initialize Razorpay client
razorpay_client = None
if settings.RAZORPAY_KEY and settings.RAZORPAY_SECRET:
    try:
        razorpay_client = razorpay.Client(auth=(settings.RAZORPAY_KEY, settings.RAZORPAY_SECRET))
    except Exception as e:
        LOGGER.error(f"Razorpay Client initialization error: {str(e)}")

class PaymentService:
    @staticmethod
    def create_order(booking_id: int, db: Session) -> dict:
        booking = db.query(Booking).filter(Booking.id == booking_id).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")

        amount = float(booking.total_price)
        if amount <= 0:
            amount = 1.0  # Fallback minimum amount in INR for testing

        if razorpay_client:
            try:
                order_data = {
                    "amount": int(amount * 100),  # amount in paise
                    "currency": "INR",
                    "receipt": f"receipt_{booking_id}"
                }
                order = razorpay_client.order.create(data=order_data)
                return {
                    "order_id": order.get("id"),
                    "amount": amount,
                    "currency": "INR",
                    "key": settings.RAZORPAY_KEY
                }
            except Exception as e:
                LOGGER.error(f"Razorpay order creation error: {str(e)}")
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Payment order creation failed: {str(e)}"
                )
        else:
            # Mock order for test mode/development fallback
            mock_order_id = f"order_mock_{booking_id}_123"
            return {
                "order_id": mock_order_id,
                "amount": amount,
                "currency": "INR",
                "key": "mock_razorpay_key",
                "mocked": True
            }

    @staticmethod
    def verify_payment(
        booking_id: int,
        razorpay_order_id: str,
        razorpay_payment_id: str,
        razorpay_signature: str,
        db: Session,
        background_tasks = None
    ) -> bool:
        booking = db.query(Booking).filter(Booking.id == booking_id).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")

        is_verified = False
        if razorpay_client and not razorpay_order_id.startswith("order_mock_"):
            try:
                params_dict = {
                    'razorpay_order_id': razorpay_order_id,
                    'razorpay_payment_id': razorpay_payment_id,
                    'razorpay_signature': razorpay_signature
                }
                razorpay_client.utility.verify_payment_signature(params_dict)
                is_verified = True
            except Exception as e:
                LOGGER.error(f"Razorpay payment verification error: {str(e)}")
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid payment signature")
        else:
            # Mock verification success for testing
            is_verified = True

        if is_verified:
            booking.payment_status = "paid"
            
            user_id = booking.tourist.user_id if booking.tourist else None
            if not user_id:
                user_id = booking.tourist_id

            payment = Payment(
                booking_id=booking.id,
                user_id=user_id,
                amount=booking.total_price,
                method="razorpay",
                status="paid"
            )
            db.add(payment)
            db.commit()

            # Trigger email notification on payment success
            email = None
            name = "Guest"
            if booking.tourist:
                email = booking.tourist.email or (booking.tourist.user.email if booking.tourist.user else None)
                name = booking.tourist.name
            
            if email:
                subject = "Booking Payment Successful"
                body = f"Hi {name}, your payment of INR {booking.total_price} for booking ID {booking.id} was successful. Thanks for traveling with us!"
                if background_tasks and hasattr(background_tasks, "add_task"):
                    background_tasks.add_task(EmailService.send_email, email, subject, body)
                else:
                    EmailService.send_email(email, subject, body)

            return True

        return False

    @staticmethod
    def get_payments(db: Session, user_id: int) -> list[Payment]:
        return db.query(Payment).filter(Payment.user_id == user_id).all()
