from sqlalchemy.orm import Session
from sqlalchemy import func
from fastapi import HTTPException, status
from typing import Optional, List
from datetime import date as DateType, timedelta

from app.models.user import Farmer, Login
from app.models.farm import FarmListing
from app.models.booking import Booking
from app.schemas.farm import FarmListingCreate

class FarmService:
    @staticmethod
    def _farm_review_map(db: Session, farm_ids: list[int]) -> dict[int, int]:
        if not farm_ids:
            return {}
        rows = (
            db.query(Booking.farm_id, func.count(Booking.id))
            .filter(Booking.booking_type == "farm", Booking.farm_id.in_(farm_ids))
            .group_by(Booking.farm_id)
            .all()
        )
        return {int(farm_id): int(count) for farm_id, count in rows}

    @staticmethod
    def _farm_payload(
        farm: FarmListing,
        review_count: int = 0,
        match_score: Optional[int] = None,
        available: Optional[bool] = None,
    ) -> dict:
        mock_rating = 4.0 + (farm.id % 10) / 10.0
        if mock_rating > 5.0:
            mock_rating = 5.0

        payload = {
            "id": farm.id,
            "farm_name": farm.farm_name,
            "name": farm.farm_name,
            "farmer_id": farm.farmer_id,
            "user_id": farm.owner.user_id if farm.owner else None,
            "description": farm.description,
            "location": f"{farm.city}, {farm.state}" if farm.city and farm.state else (farm.city or farm.state or ""),
            "area": farm.address,
            "city": farm.city,
            "state": farm.state,
            "mobile": farm.mobile,
            "email": farm.email,
            "crop_types": farm.crop_types,
            "farm_photo": farm.farm_photo,
            "stay_available": bool(farm.stay_available),
            "transport_available": bool(farm.transport_available),
            "activities": farm.activities,
            "price_per_night": float(farm.price_per_night) if farm.price_per_night else None,
            "is_active": farm.is_active,
            "created_at": farm.created_at.isoformat() if getattr(farm, "created_at", None) else None,
            "is_verified": farm.owner.is_verified if getattr(farm, "owner", None) else False,
            "review_count": review_count,
            "reviews": review_count,
            "rating": mock_rating,
            "avg_rating": mock_rating,
        }

        if match_score is not None:
            payload["matchScore"] = match_score
        if available is not None:
            payload["available"] = available
        return payload

    @staticmethod
    def get_farm_listing(db: Session, listing_id: int) -> FarmListing:
        f = db.query(FarmListing).filter(FarmListing.id == listing_id).first()
        if not f:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farm listing not found")
        return f

    @staticmethod
    def check_farm_availability(db: Session, listing_id: int, date_start: DateType, date_end: DateType):
        overlap = (
            db.query(Booking)
            .filter(
                Booking.booking_type == "farm",
                Booking.farm_id == listing_id,
                Booking.status != "cancelled",
                Booking.check_in <= date_end,
                Booking.check_out >= date_start,
            )
            .first()
        )
        
        if not overlap:
            return {"available": True, "suggested_dates": []}

        duration = (date_end - date_start).days
        if duration <= 0:
            duration = 1
            
        future_bookings = (
            db.query(Booking.check_in, Booking.check_out)
            .filter(
                Booking.booking_type == "farm",
                Booking.farm_id == listing_id,
                Booking.status != "cancelled",
                Booking.check_out >= date_start
            )
            .order_by(Booking.check_in)
            .all()
        )
        
        suggested = []
        current_start = overlap.check_out + timedelta(days=1)
        
        for _ in range(3):
            while True:
                current_end = current_start + timedelta(days=duration)
                conflict = False
                for fb_in, fb_out in future_bookings:
                    if current_start <= fb_out and current_end >= fb_in:
                        conflict = True
                        current_start = fb_out + timedelta(days=1)
                        break 
                if not conflict:
                    suggested.append({
                        "check_in": current_start.isoformat(),
                        "check_out": current_end.isoformat()
                    })
                    current_start = current_end + timedelta(days=1)
                    break

        return {"available": False, "suggested_dates": suggested}

    @classmethod
    def get_farmer_listings(cls, db: Session, user_id: int) -> List[FarmListing]:
        farmer = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not farmer:
            return []
        return (
            db.query(FarmListing)
            .filter(FarmListing.farmer_id == farmer.id)
            .order_by(FarmListing.created_at.desc())
            .all()
        )

    @classmethod
    def create_farm_listing(cls, db: Session, user_id: int, data: FarmListingCreate) -> FarmListing:
        farmer = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not farmer:
            login = db.query(Login).filter(Login.id == user_id).first()
            farmer = Farmer(
                user_id=user_id,
                name=login.full_name if login else "Unknown",
                mobile=login.mobile if login else None,
                email=login.email if login else None,
            )
            db.add(farmer)
            db.flush()

        login = db.query(Login).filter(Login.id == user_id).first()
        if login:
            login.role = "farmer"

        listing = FarmListing(farmer_id=farmer.id, **data.dict())
        db.add(listing)
        db.commit()
        db.refresh(listing)
        return listing

    @classmethod
    def update_farm_listing(cls, db: Session, listing_id: int, data: FarmListingCreate) -> FarmListing:
        f = db.query(FarmListing).filter(FarmListing.id == listing_id).first()
        if not f:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farm listing not found")
        for k, v in data.dict(exclude_none=True).items():
            setattr(f, k, v)
        db.commit()
        db.refresh(f)
        return f

    @classmethod
    def delete_farm_listing(cls, db: Session, listing_id: int, user_id: int):
        farmer = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not farmer:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farmer profile not found")

        listing = (
            db.query(FarmListing)
            .filter(FarmListing.id == listing_id, FarmListing.farmer_id == farmer.id)
            .first()
        )
        if not listing:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farm listing not found")

        db.delete(listing)
        db.commit()
        return {"message": "Listing deleted successfully"}

    @classmethod
    def list_all_farms(cls, db: Session, skip: int = 0, limit: int = 50) -> List[dict]:
        farms = db.query(FarmListing).offset(skip).limit(limit).all()
        review_map = cls._farm_review_map(db, [f.id for f in farms])
        return [cls._farm_payload(f, review_count=review_map.get(f.id, 0)) for f in farms]

    @classmethod
    def search_farms(
        cls,
        db: Session,
        user_id: int,
        query: Optional[str] = None,
        date_start: Optional[DateType] = None,
        date_end: Optional[DateType] = None,
        time_slot: Optional[str] = None
    ) -> List[dict]:
        farms = db.query(FarmListing).filter(FarmListing.is_active == True).all()
        review_map = cls._farm_review_map(db, [f.id for f in farms])

        unavailable_ids = set()
        if date_start and date_end:
            overlapping = db.query(Booking.farm_id).filter(
                Booking.booking_type == "farm",
                Booking.check_in <= date_end,
                Booking.check_out >= date_start,
            ).all()
            unavailable_ids = {row[0] for row in overlapping if row[0] is not None}

        def is_available(f: FarmListing) -> bool:
            available = True
            if date_start and date_end and f.id in unavailable_ids:
                available = False

            if available and time_slot:
                slot = time_slot.lower()
                stay_text = (f.stay_available or "").lower()
                if slot and stay_text:
                    available = slot in stay_text
                else:
                    available = False
            return available

        if query:
            from app.ai.recommender import recommender_agent
            results = recommender_agent.get_recommendations(query, farms, item_type="farm")
            output = []
            for r in results:
                f = r["item"]
                output.append(
                    cls._farm_payload(
                        f,
                        review_count=review_map.get(f.id, 0),
                        match_score=r["matchScore"],
                        available=is_available(f),
                    )
                )
            return output

        return [
            cls._farm_payload(f, review_count=review_map.get(f.id, 0), available=is_available(f))
            for f in farms
        ]
