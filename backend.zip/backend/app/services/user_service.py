from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from typing import Optional, List
from collections import defaultdict

from app.models.user import Login, Tourist, Creator, Farmer, ContactUs, Notification, Message
from app.schemas import (
    FarmerProfileOut, FarmerRegisterRequest, TouristOut, TouristUpdate,
    CreatorOut, CreatorRegisterRequest, ContactCreate, ContactOut,
    MessageCreate, MessageOut
)

class UserService:
    @staticmethod
    def register_farmer(db: Session, data: FarmerRegisterRequest, user_id: int) -> FarmerProfileOut:
        farmer_profile = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        profile_data = data.profile.dict(exclude_none=True)

        if not farmer_profile:
            farmer_profile = Farmer(user_id=user_id, **profile_data)
            db.add(farmer_profile)
        else:
            for key, value in profile_data.items():
                setattr(farmer_profile, key, value)

        login = db.query(Login).filter(Login.id == user_id).first()
        if login:
            login.role = "farmer"
            if data.profile.mobile:
                login.mobile = data.profile.mobile

        db.commit()
        db.refresh(farmer_profile)
        return farmer_profile

    @staticmethod
    def get_farmer_profile(db: Session, user_id: int) -> Farmer:
        f = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not f:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farmer profile not found")
        return f

    @staticmethod
    def get_farmer_by_profile_id(db: Session, farmer_id: int) -> Farmer:
        f = db.query(Farmer).filter(Farmer.id == farmer_id).first()
        if not f:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farmer profile not found")
        return f

    @staticmethod
    def update_farmer_profile(db: Session, user_id: int, data: Optional[dict] = None) -> Farmer:
        f = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not f:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farmer profile not found")
        if data:
            allowed_fields = {"name", "street_address", "city", "area", "state", "postal_code", "mobile", "email", "age", "country", "aadhaar_no"}
            for key, value in data.items():
                if key in allowed_fields and value is not None and value != "":
                    setattr(f, key, value)
            if data.get("mobile"):
                login_obj = db.query(Login).filter(Login.id == user_id).first()
                if login_obj:
                    login_obj.mobile = data["mobile"]
        db.commit()
        db.refresh(f)
        return f

    @staticmethod
    def get_tourist_profile(db: Session, user_id: int) -> Tourist:
        t = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tourist not found")
        return t

    @staticmethod
    def update_tourist_profile(db: Session, user_id: int, data: TouristUpdate) -> Tourist:
        t = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tourist not found")
        for k, v in data.dict(exclude_none=True).items():
            setattr(t, k, v)
        db.commit()
        db.refresh(t)
        return t

    @staticmethod
    def get_wishlist(db: Session, user_id: int) -> dict:
        t = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tourist not found")
        return {"wishlist": t.wishlist}

    @staticmethod
    def update_wishlist(db: Session, user_id: int, wishlist: str) -> dict:
        t = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not t:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tourist not found")
        t.wishlist = wishlist
        db.commit()
        return {"success": True}

    @staticmethod
    def register_creator(db: Session, data: CreatorRegisterRequest, user_id: int) -> Creator:
        existing = db.query(Creator).filter(Creator.user_id == user_id).first()
        if existing:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Already registered as creator")

        creator = Creator(user_id=user_id, **data.dict())
        db.add(creator)

        login = db.query(Login).filter(Login.id == user_id).first()
        if login:
            login.role = "creator"
            if data.mobile:
                login.mobile = data.mobile

        db.commit()
        db.refresh(creator)
        return creator

    @staticmethod
    def get_creator_profile(db: Session, user_id: int) -> Creator:
        c = db.query(Creator).filter(Creator.user_id == user_id).first()
        if not c:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Creator not found")
        return c

    @staticmethod
    def get_creator_by_id(db: Session, creator_id: int) -> Creator:
        c = db.query(Creator).filter(Creator.id == creator_id).first()
        if not c:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Creator not found")
        return c

    @staticmethod
    def update_creator_profile(db: Session, user_id: int, data: CreatorRegisterRequest) -> Creator:
        c = db.query(Creator).filter(Creator.user_id == user_id).first()
        if not c:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Creator not found")
        for k, v in data.dict(exclude_none=True).items():
            setattr(c, k, v)
        db.commit()
        db.refresh(c)
        return c

    @staticmethod
    def get_messages(db: Session, user_id: int) -> list:
        messages = (
            db.query(Message)
            .filter((Message.sender_id == user_id) | (Message.receiver_id == user_id))
            .order_by(Message.created_at.asc())
            .all()
        )

        conversations = defaultdict(list)
        partner_ids = set()
        for m in messages:
            partner_id = m.receiver_id if m.sender_id == user_id else m.sender_id
            partner_ids.add(partner_id)
            conversations[partner_id].append({
                "id": m.id,
                "from": "me" if m.sender_id == user_id else "them",
                "text": m.content,
                "time": m.created_at.strftime("%H:%M") if m.created_at else "",
                "is_read": m.is_read,
            })

        partners = db.query(Login).filter(Login.id.in_(partner_ids)).all()
        partner_map = {p.id: p for p in partners}

        result = []
        for pid, msgs in conversations.items():
            partner = partner_map.get(pid)
            last_msg = msgs[-1] if msgs else {}
            unread = sum(1 for m in msgs if m["from"] == "them" and not m["is_read"])
            result.append({
                "id": f"conv-{pid}",
                "partner_id": pid,
                "name": partner.full_name if partner else f"User {pid}",
                "role": partner.role.capitalize() if partner else "User",
                "last": last_msg.get("text", ""),
                "time": last_msg.get("time", ""),
                "unread": unread,
                "messages": msgs,
            })

        return result

    @staticmethod
    def send_message(db: Session, sender_id: int, data: MessageCreate):
        receiver = db.query(Login).filter(Login.id == data.receiver_id).first()
        if not receiver:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Receiver not found")

        msg = Message(sender_id=sender_id, receiver_id=data.receiver_id, content=data.content)
        db.add(msg)
        db.commit()
        db.refresh(msg)
        return {
            "id": msg.id,
            "sender_id": msg.sender_id,
            "receiver_id": msg.receiver_id,
            "content": msg.content,
            "is_read": msg.is_read,
            "created_at": msg.created_at.isoformat() if msg.created_at else None,
        }

    @staticmethod
    def get_notifications(db: Session, user_id: int) -> list:
        notifications = (
            db.query(Notification)
            .filter(Notification.user_id == user_id)
            .order_by(Notification.created_at.desc())
            .all()
        )
        return [
            {
                "id": n.id,
                "user_id": n.user_id,
                "title": n.title,
                "body": n.body,
                "category": n.category,
                "type": n.type,
                "is_read": n.is_read,
                "created_at": n.created_at.isoformat() if n.created_at else None,
            }
            for n in notifications
        ]

    @staticmethod
    def mark_notification_read(db: Session, user_id: int, notification_id: int):
        n = db.query(Notification).filter(Notification.id == notification_id).first()
        if not n:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Notification not found")
        if n.user_id != user_id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorised")
        n.is_read = True
        db.commit()
        return {"success": True}

    @staticmethod
    def mark_all_notifications_read(db: Session, user_id: int):
        db.query(Notification).filter(
            Notification.user_id == user_id, Notification.is_read == False
        ).update({"is_read": True})
        db.commit()
        return {"success": True}

    @staticmethod
    def submit_contact(db: Session, data: ContactCreate) -> ContactUs:
        c = ContactUs(name=data.name, email=data.email, topic=data.topic, message=data.message)
        db.add(c)
        db.commit()
        db.refresh(c)
        return c
