from sqlalchemy.orm import Session
from sqlalchemy import func
from fastapi import HTTPException, status
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token

from app.core.security import hash_password, verify_password, create_token
from app.core.config import settings
from app.models.user import Login, Tourist, Creator, Farmer
from app.models.farm import FarmListing
from app.models.booking import Booking
from app.schemas.user import RegisterRequest, LoginRequest, ChangePasswordRequest, TokenResponse

class AuthService:
    @staticmethod
    def register(db: Session, req: RegisterRequest, background_tasks = None) -> TokenResponse:
        existing = (
            db.query(Login)
            .filter((Login.email == req.email) | (Login.mobile == req.mobile))
            .first()
        )
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email or mobile already registered. Please log in instead.",
            )

        login = Login(
            email=req.email,
            password=hash_password(req.password),
            full_name=req.full_name,
            mobile=req.mobile,
            role="tourist"
        )
        db.add(login)
        db.flush()

        tourist = Tourist(
            user_id=login.id,
            name=req.full_name,
            mobile=req.mobile
        )
        db.add(tourist)
        db.commit()
        db.refresh(login)
        db.refresh(tourist)

        try:
            from app.services.email_service import EmailService
            subject = "Welcome to Namma Connect!"
            body = f"Hi {req.full_name}, thank you for registering with Namma Connect. Explore farms and start booking stays!"
            if background_tasks and hasattr(background_tasks, "add_task"):
                background_tasks.add_task(EmailService.send_email, req.email, subject, body)
            else:
                EmailService.send_email(req.email, subject, body)
        except Exception:
            pass

        token = create_token({"sub": str(login.id), "role": "tourist"})
        return TokenResponse(
            access_token=token,
            profile_id=tourist.id,
            user_id=login.id,
            role="tourist",
            name=tourist.name,
            email=login.email,
            mobile=login.mobile,
        )

    @staticmethod
    def login(db: Session, req: LoginRequest) -> TokenResponse:
        identifier = req.identifier.strip()
        login_obj = db.query(Login).filter(
            (func.lower(Login.email) == identifier.lower()) |
            (Login.mobile == identifier)
        ).first()

        if not login_obj:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Account not found"
            )

        if not verify_password(req.password, login_obj.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Password is incorrect"
            )

        role = login_obj.role
        name = ""
        profile_id = login_obj.id

        if role == "tourist" and login_obj.tourist:
            name = login_obj.tourist.name
            profile_id = login_obj.tourist.id
        elif role == "creator" and login_obj.creator:
            name = login_obj.creator.name
            profile_id = login_obj.creator.id
        elif role == "farmer" and login_obj.farmer:
            name = login_obj.farmer.name
            profile_id = login_obj.farmer.id
        elif role == "admin":
            name = login_obj.full_name
            profile_id = login_obj.id

        token = create_token({"sub": str(login_obj.id), "role": role})

        return TokenResponse(
            access_token=token,
            profile_id=profile_id,
            user_id=login_obj.id,
            role=role,
            name=name,
            email=login_obj.email,
            mobile=login_obj.mobile,
        )

    @staticmethod
    def google_login(db: Session, credential: str) -> TokenResponse:
        try:
            idinfo = id_token.verify_oauth2_token(credential, google_requests.Request(), settings.GOOGLE_CLIENT_ID)
            email = idinfo["email"]
            name = idinfo.get("name", "")
        except Exception:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid Google authentication")

        login_obj = db.query(Login).filter(Login.email == email).first()
        if not login_obj:
            login_obj = Login(
                email=email, 
                password="google-auth", 
                full_name=name,
                mobile=None,
                role="tourist"
            )
            db.add(login_obj)
            db.flush()
            
            tourist = Tourist(user_id=login_obj.id, name=name)
            db.add(tourist)
            db.commit()
            db.refresh(login_obj)
            db.refresh(tourist)
        
        profile_id = login_obj.id
        role = login_obj.role
        if role == "tourist" and login_obj.tourist:
            profile_id = login_obj.tourist.id
        elif role == "creator" and login_obj.creator:
            profile_id = login_obj.creator.id
        elif role == "farmer" and login_obj.farmer:
            profile_id = login_obj.farmer.id

        token = create_token({"sub": str(login_obj.id), "role": role})
        return TokenResponse(
            access_token=token,
            profile_id=profile_id,
            user_id=login_obj.id,
            role=role,
            name=name,
            email=login_obj.email,
            mobile=login_obj.mobile,
        )

    @staticmethod
    def change_password(db: Session, req: ChangePasswordRequest):
        identifier = req.identifier.strip()
        login_obj = db.query(Login).filter(
            (func.lower(Login.email) == identifier.lower()) |
            (Login.mobile == identifier)
        ).first()

        if not login_obj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found with provided email/mobile")
        
        login_obj.password = hash_password(req.new_password)
        db.commit()
        return {"message": "Password updated successfully"}

    @staticmethod
    def change_password_authenticated(db: Session, user_id: int, req: ChangePasswordRequest):
        login_obj = db.query(Login).filter(Login.id == user_id).first()
        if not login_obj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        if not verify_password(req.identifier, login_obj.password):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Current password is incorrect")

        login_obj.password = hash_password(req.new_password)
        db.commit()
        return {"message": "Password updated successfully"}

    @staticmethod
    def delete_account(db: Session, user_id: int):
        login_obj = db.query(Login).filter(Login.id == user_id).first()
        if not login_obj:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Account not found")

        role = login_obj.role

        tourist_profile = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if tourist_profile:
            db.query(Booking).filter(Booking.tourist_id == tourist_profile.id).delete()

        if role == "farmer":
            farmer = db.query(Farmer).filter(Farmer.user_id == user_id).first()
            if farmer:
                db.query(FarmListing).filter(FarmListing.farmer_id == farmer.id).delete()
                listing_ids = [l.id for l in db.query(FarmListing).filter(FarmListing.farmer_id == farmer.id).all()]
                if listing_ids:
                    db.query(Booking).filter(Booking.farm_id.in_(listing_ids), Booking.booking_type == "farm").delete()
                db.delete(farmer)

        elif role == "creator":
            creator = db.query(Creator).filter(Creator.user_id == user_id).first()
            if creator:
                db.query(Booking).filter(Booking.creator_id == creator.id, Booking.booking_type == "creator").delete()
                db.delete(creator)

        elif role == "tourist":
            tourist = db.query(Tourist).filter(Tourist.user_id == user_id).first()
            if tourist:
                db.delete(tourist)

        db.delete(login_obj)
        db.commit()
        return {"message": "Account deleted successfully"}
