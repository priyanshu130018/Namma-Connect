from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from fastapi import HTTPException, status
from typing import Optional, List
from datetime import date as DateType, timedelta

from app.models.user import Tourist, Login, Farmer, Creator
from app.models.farm import FarmListing
from app.models.booking import Booking
from app.schemas.booking import BookingCreate, BookingStatusUpdate

class BookingService:
    @staticmethod
    def _populate_booking_extra(b: Booking):
        """Helper to add transient fields for frontend."""
        if b.booking_type == "farm" and b.farm:
            b.item_name = b.farm.farm_name
            b.item_emoji = "🌾"
            b.region = b.farm.state
        elif b.booking_type == "creator" and b.creator:
            b.item_name = b.creator.name
            b.item_emoji = "🎬"
            b.region = b.creator.state
        
        if b.tourist:
            b.tourist_name = b.tourist.name
        return b

    @classmethod
    def create_booking(cls, db: Session, data: BookingCreate, user_id: int) -> Booking:
        tourist_profile = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not tourist_profile:
            login_obj = db.query(Login).filter(Login.id == user_id).first()
            if not login_obj:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
            tourist_profile = Tourist(user_id=user_id, name=login_obj.full_name)
            db.add(tourist_profile)
            db.flush()

        # Prohibit self-booking
        if data.booking_type == "farm" and data.farm_id:
            farm = db.query(FarmListing).filter(FarmListing.id == data.farm_id).first()
            if not farm:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farm not found")
            owner = db.query(Farmer).filter(Farmer.id == farm.farmer_id).first()
            if owner and owner.user_id == user_id:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Strictly prohibited: You cannot book your own farm listing.")
        
        if data.booking_type == "creator" and data.creator_id:
            creator = db.query(Creator).filter(Creator.id == data.creator_id).first()
            if not creator:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Creator not found")
            if creator.user_id == user_id:
                 raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Strictly prohibited: You cannot book your own services.")

        # Check availability (overlapping bookings)
        overlap_filter = [
            Booking.booking_type == data.booking_type,
            Booking.status != "cancelled",
            Booking.check_in <= data.check_out,
            Booking.check_out >= data.check_in
        ]
        if data.booking_type == "farm":
            overlap_filter.append(Booking.farm_id == data.farm_id)
        else:
            overlap_filter.append(Booking.creator_id == data.creator_id)

        overlap = db.query(Booking).filter(and_(*overlap_filter)).first()
        if overlap:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Not available for the selected dates. Please choose a different range.",
            )

        booking = Booking(
            tourist_id=tourist_profile.id,
            booking_type=data.booking_type,
            farm_id=data.farm_id,
            creator_id=data.creator_id,
            check_in=data.check_in,
            check_out=data.check_out,
            adults=data.adults,
            children=data.children,
            guests=data.adults + data.children,
            total_price=data.total_price,
            collab_note=data.collab_note,
            status="pending",
        )
        db.add(booking)
        db.commit()
        db.refresh(booking)
        
        try:
            email = tourist_profile.email or (tourist_profile.user.email if tourist_profile.user else None)
            if email:
                from app.services.email_service import EmailService
                subject = "Booking Received"
                body = f"Hi {tourist_profile.name}, your booking request for {data.booking_type} was received and is currently pending."
                EmailService.send_email(email, subject, body)
        except Exception:
            pass
        
        return cls._populate_booking_extra(booking)

    @classmethod
    def get_tourist_bookings(cls, db: Session, user_id: int, status: Optional[str] = None) -> List[Booking]:
        tourist_profile = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not tourist_profile:
            return []

        query = db.query(Booking).filter(Booking.tourist_id == tourist_profile.id)
        if status:
            query = query.filter(Booking.status == status)
        bookings = query.order_by(Booking.created_at.desc()).all()
        for b in bookings:
            cls._populate_booking_extra(b)
        return bookings

    @classmethod
    def cancel_booking(cls, db: Session, booking_id: int, user_id: int):
        tourist_profile = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        if not tourist_profile:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tourist profile not found")

        booking = db.query(Booking).filter(
            Booking.id == booking_id,
            Booking.tourist_id == tourist_profile.id
        ).first()
        
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")

        booking.status = "cancelled"
        db.commit()
        cls._send_status_email(booking)
        return {"success": True}

    @classmethod
    def update_booking_status(cls, db: Session, booking_id: int, data: BookingStatusUpdate):
        booking = db.query(Booking).filter(Booking.id == booking_id).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")
        
        booking.status = data.status
        db.commit()
        cls._send_status_email(booking)
        return {"success": True, "status": data.status}

    @classmethod
    def get_farmer_bookings(cls, db: Session, user_id: int) -> dict:
        farmer = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not farmer:
            return {"received": [], "made": []}

        farm_ids = [f.id for f in farmer.listings]
        received = []
        if farm_ids:
            received = (
                db.query(Booking)
                .filter(Booking.booking_type == "farm", Booking.farm_id.in_(farm_ids))
                .order_by(Booking.created_at.desc())
                .all()
            )

        for r in received:
            cls._populate_booking_extra(r)

        tourist_profile = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        made = []
        if tourist_profile:
            made = db.query(Booking).filter(Booking.tourist_id == tourist_profile.id).order_by(Booking.created_at.desc()).all()
            for m in made:
                cls._populate_booking_extra(m)

        return {"received": received, "made": made}

    @classmethod
    def update_farmer_booking_status(cls, db: Session, booking_id: int, user_id: int, data: BookingStatusUpdate):
        farmer = db.query(Farmer).filter(Farmer.user_id == user_id).first()
        if not farmer:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Farmer profile not found")

        booking = db.query(Booking).filter(Booking.id == booking_id).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")

        if not booking.farm_id or booking.farm.farmer_id != farmer.id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to update this booking")

        booking.status = data.status
        db.commit()
        cls._send_status_email(booking)
        return {"success": True, "status": data.status}

    @classmethod
    def get_creator_bookings(cls, db: Session, user_id: int) -> dict:
        creator = db.query(Creator).filter(Creator.user_id == user_id).first()
        if not creator:
            return {"received": [], "made": []}
        
        received = db.query(Booking).filter(
            Booking.creator_id == creator.id, 
            Booking.booking_type == "creator"
        ).order_by(Booking.created_at.desc()).all()
        
        for r in received:
            cls._populate_booking_extra(r)

        tourist_profile = db.query(Tourist).filter(Tourist.user_id == user_id).first()
        made = []
        if tourist_profile:
            made = db.query(Booking).filter(Booking.tourist_id == tourist_profile.id).order_by(Booking.created_at.desc()).all()
            for m in made:
                cls._populate_booking_extra(m)

        return {"received": received, "made": made}

    @classmethod
    def update_creator_booking_status(cls, db: Session, booking_id: int, user_id: int, data: BookingStatusUpdate):
        creator = db.query(Creator).filter(Creator.user_id == user_id).first()
        if not creator:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Creator profile not found")

        booking = db.query(Booking).filter(Booking.id == booking_id).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found")

        if not booking.creator_id or booking.creator.id != creator.id:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to update this booking")

        booking.status = data.status
        db.commit()
        cls._send_status_email(booking)
        return {"success": True, "status": data.status}

    @classmethod
    def check_creator_availability(cls, db: Session, creator_id: int, date_start: DateType, date_end: DateType):
        overlap = (
            db.query(Booking)
            .filter(
                Booking.booking_type == "creator",
                Booking.creator_id == creator_id,
                Booking.status != "cancelled",
                Booking.check_in <= date_end,
                Booking.check_out >= date_start,
            )
            .first()
        )
        
        if not overlap:
            return {"available": True, "suggested_dates": []}

        duration = (date_end - date_start).days
        if duration <= 0:
            duration = 1
            
        future_bookings = (
            db.query(Booking.check_in, Booking.check_out)
            .filter(
                Booking.booking_type == "creator",
                Booking.creator_id == creator_id,
                Booking.status != "cancelled",
                Booking.check_out >= date_start
            )
            .order_by(Booking.check_in)
            .all()
        )
        
        suggested = []
        current_start = overlap.check_out + timedelta(days=1)
        
        for _ in range(3):
            while True:
                current_end = current_start + timedelta(days=duration)
                conflict = False
                for fb_in, fb_out in future_bookings:
                    if current_start <= fb_out and current_end >= fb_in:
                        conflict = True
                        current_start = fb_out + timedelta(days=1)
                        break 
                if not conflict:
                    suggested.append({
                        "check_in": current_start.isoformat(),
                        "check_out": current_end.isoformat()
                    })
                    current_start = current_end + timedelta(days=1)
                    break

        return {"available": False, "suggested_dates": suggested}

    @classmethod
    def get_collaborations(cls, db: Session, user_id: int) -> dict:
        creator = db.query(Creator).filter(Creator.user_id == user_id).first()
        if not creator:
            return {"received": [], "made": []}

        bookings = (
            db.query(Booking)
            .filter(Booking.creator_id == creator.id, Booking.booking_type == "creator")
            .order_by(Booking.created_at.desc())
            .all()
        )

        received = []
        for b in bookings:
            tourist_name = b.tourist.name if b.tourist else "Unknown"
            received.append({
                "id": b.id,
                "tourist_id": b.tourist_id,
                "tourist_name": tourist_name,
                "item_name": creator.name,
                "item_emoji": "🎬",
                "check_in": b.check_in.isoformat() if b.check_in else None,
                "check_out": b.check_out.isoformat() if b.check_out else None,
                "adults": b.adults,
                "children": b.children,
                "total_price": float(b.total_price) if b.total_price else 0,
                "collab_note": b.collab_note,
                "status": b.status,
                "created_at": b.created_at.isoformat() if b.created_at else None,
            })

        return {"received": received, "made": []}

    @classmethod
    def update_collab_status(cls, db: Session, booking_id: int, user_id: int, status_str: str) -> dict:
        creator = db.query(Creator).filter(Creator.user_id == user_id).first()
        if not creator:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Creator profile not found")

        booking = db.query(Booking).filter(
            Booking.id == booking_id,
            Booking.creator_id == creator.id,
            Booking.booking_type == "creator",
        ).first()
        if not booking:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Booking not found or not authorised")

        if status_str not in ("pending", "confirmed", "cancelled", "completed"):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid status")

        booking.status = status_str
        db.commit()
        cls._send_status_email(booking)
        return {"id": booking_id, "status": booking.status, "success": True}

    @staticmethod
    def _send_status_email(booking: Booking):
        try:
            tourist = booking.tourist
            if tourist:
                email = tourist.email or (tourist.user.email if tourist.user else None)
                if email:
                    from app.services.email_service import EmailService
                    subject = f"Booking {booking.status.capitalize()}"
                    if booking.status == "confirmed":
                        body = f"Hi {tourist.name}, your booking request for {booking.booking_type} has been confirmed. Thank you!"
                    elif booking.status == "cancelled":
                        body = f"Hi {tourist.name}, your booking request for {booking.booking_type} has been cancelled."
                    else:
                        body = f"Hi {tourist.name}, your booking request for {booking.booking_type} status has been updated to {booking.status}."
                    EmailService.send_email(email, subject, body)
        except Exception:
            pass
