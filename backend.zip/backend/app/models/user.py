from sqlalchemy import Column, Integer, String, Text, Boolean, ForeignKey, TIMESTAMP, func, Enum, Numeric
from sqlalchemy.orm import relationship
from app.core.database import Base

class Login(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password = Column(String(255), nullable=False)  # Stores hashed password
    role = Column(Enum("tourist", "creator", "farmer", "admin", name="user_roles"), nullable=False)
    mobile = Column(String(15))
    is_active = Column(Boolean, default=True)
    created_at = Column(TIMESTAMP, server_default=func.now())

    # Relationships to profile tables with cascade delete
    tourist = relationship("Tourist", back_populates="user", uselist=False, cascade="all, delete-orphan")
    creator = relationship("Creator", back_populates="user", uselist=False, cascade="all, delete-orphan")
    farmer  = relationship("Farmer",  back_populates="user", uselist=False, cascade="all, delete-orphan")


class Tourist(Base):
    __tablename__ = "tourist"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(150), nullable=False)
    age = Column(Integer)
    address = Column(String(255))
    city = Column(String(100), index=True)
    state = Column(String(100), index=True)
    country = Column(String(100), default="India")
    postal_code = Column(String(20))
    mobile = Column(String(15))
    email = Column(String(150))
    aadhaar_no = Column(String(12))
    is_verified = Column(Boolean, default=False)
    bio = Column(Text)
    wishlist = Column(Text)
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    user = relationship("Login", back_populates="tourist")
    bookings_made = relationship("Booking", back_populates="tourist", cascade="all, delete-orphan")


class Creator(Base):
    __tablename__ = "creator"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(150), nullable=False)
    age = Column(Integer)
    address = Column(String(255))
    city = Column(String(100), index=True)
    state = Column(String(100), index=True)
    country = Column(String(100), default="India")
    postal_code = Column(String(20))
    mobile = Column(String(15))
    email = Column(String(150))
    aadhaar_no = Column(String(12))
    is_verified = Column(Boolean, default=False)
    niche = Column(String(150))
    portfolio = Column(String(255))
    instagram = Column(String(150))
    youtube = Column(String(150))
    has_work_experience = Column(Boolean, default=False)
    bio = Column(Text)
    rate = Column(Numeric(10, 2), default=0.00)
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    user = relationship("Login", back_populates="creator")
    bookings_received = relationship("Booking", back_populates="creator", cascade="all, delete-orphan")


class Farmer(Base):
    __tablename__ = "farmer"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(150), nullable=False)
    age = Column(Integer)
    address = Column(String(255))
    city = Column(String(100), index=True)
    state = Column(String(100), index=True)
    country = Column(String(100), default="India")
    postal_code = Column(String(20))
    mobile = Column(String(15))
    email = Column(String(150))
    aadhaar_no = Column(String(12))
    identity_proof = Column(Text)
    is_verified = Column(Boolean, default=False)
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    user = relationship("Login", back_populates="farmer")
    listings = relationship("FarmListing", back_populates="owner", cascade="all, delete-orphan")


class ContactUs(Base):
    __tablename__ = "contact_us"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    email = Column(String(255), nullable=False)
    topic = Column(String(150))
    message = Column(Text)
    created_at = Column(TIMESTAMP, server_default=func.now())


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(255), nullable=False)
    body = Column(Text)
    category = Column(String(100), default="general")
    type = Column(String(50), default="info")
    is_read = Column(Boolean, default=False)
    created_at = Column(TIMESTAMP, server_default=func.now())


class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, index=True)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    receiver_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    content = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(TIMESTAMP, server_default=func.now())
