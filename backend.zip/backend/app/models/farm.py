from sqlalchemy import Column, Integer, String, Text, Boolean, ForeignKey, TIMESTAMP, func, Numeric
from sqlalchemy.orm import relationship
from app.core.database import Base

class FarmListing(Base):
    __tablename__ = "farm_listing"

    id = Column(Integer, primary_key=True, index=True)
    farmer_id = Column(Integer, ForeignKey("farmer.id"), nullable=False)
    farm_name = Column(String(255), nullable=False)
    description = Column(Text)
    address = Column(String(255))
    city = Column(String(100), index=True)
    state = Column(String(100), index=True)
    mobile = Column(String(20))
    email = Column(String(255))
    crop_types = Column(String(500))
    farm_photo = Column(String(500))
    stay_available = Column(String(100))
    transport_available = Column(String(100))
    activities = Column(Text)
    price_per_night = Column(Numeric(10, 2), index=True)
    latitude = Column(Numeric(10, 7), nullable=True)
    longitude = Column(Numeric(10, 7), nullable=True)
    is_active = Column(Boolean, default=True, index=True)
    created_at = Column(TIMESTAMP, server_default=func.now())

    owner = relationship("Farmer", back_populates="listings")
    bookings = relationship("Booking", back_populates="farm", cascade="all, delete-orphan")

    @property
    def user_id(self):
        return self.owner.user_id if self.owner else None
