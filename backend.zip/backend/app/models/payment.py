from sqlalchemy import Column, Integer, String, ForeignKey, TIMESTAMP, func, Enum, Numeric
from app.core.database import Base

class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("booking.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    amount = Column(Numeric(10, 2), nullable=False)
    method = Column(String(50))
    status = Column(Enum("pending", "paid", "failed", name="payment_status"), default="pending")
    created_at = Column(TIMESTAMP, server_default=func.now())
