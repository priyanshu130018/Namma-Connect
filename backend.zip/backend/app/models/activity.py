from sqlalchemy import Column, Integer, String, Text, ForeignKey, TIMESTAMP, func, Numeric
from app.core.database import Base

class Activity(Base):
    __tablename__ = "activities"
    id = Column(Integer, primary_key=True, index=True)
    farm_id = Column(Integer, ForeignKey("farm_listing.id"), nullable=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    location = Column(String(255))
    price = Column(Numeric(10, 2), default=0.00)
    duration = Column(String(100))
    category = Column(String(100))
    status = Column(String(50), default="active")
    created_at = Column(TIMESTAMP, server_default=func.now())
