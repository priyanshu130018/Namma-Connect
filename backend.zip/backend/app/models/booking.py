from sqlalchemy import Column, Integer, String, Text, Date, ForeignKey, TIMESTAMP, func, Enum, Numeric, CheckConstraint
from sqlalchemy.orm import relationship
from app.core.database import Base

class Booking(Base):
    __tablename__ = "booking"

    __table_args__ = (
        CheckConstraint(
            "(booking_type = 'farm' AND farm_id IS NOT NULL AND creator_id IS NULL) OR "
            "(booking_type = 'creator' AND creator_id IS NOT NULL AND farm_id IS NULL)",
            name="check_booking_type_integrity"
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    tourist_id = Column(Integer, ForeignKey("tourist.id"), nullable=False)
    booking_type = Column(Enum("farm", "creator", name="booking_types"), nullable=False)
    farm_id = Column(Integer, ForeignKey("farm_listing.id"), nullable=True)
    creator_id = Column(Integer, ForeignKey("creator.id"), nullable=True)
    check_in = Column(Date, nullable=False)
    check_out = Column(Date, nullable=False)
    adults = Column(Integer, nullable=False, default=1)
    children = Column(Integer, nullable=False, default=0)
    guests = Column(Integer, nullable=False, default=1)
    total_price = Column(Numeric(10, 2), default=0.00)
    collab_note = Column(Text)
    status = Column(Enum("pending", "confirmed", "cancelled", "completed", name="booking_status"), default="pending")
    payment_status = Column(String(50), default="unpaid")
    created_at = Column(TIMESTAMP, server_default=func.now())
    updated_at = Column(TIMESTAMP, server_default=func.now(), onupdate=func.now())

    # Relationships
    tourist = relationship("Tourist", back_populates="bookings_made")
    farm = relationship("FarmListing", back_populates="bookings")
    creator = relationship("Creator", back_populates="bookings_received")
