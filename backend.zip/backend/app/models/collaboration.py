# Collaborations are represented using the Booking model with booking_type='creator'.
# There is no dedicated collaborations table in the database schema.
