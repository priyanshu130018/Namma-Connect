from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import date as DateType

from app.core.database import get_db
from app.services.farm_service import FarmService
from app.schemas.farm import FarmListingCreate, FarmListingOut
from app.dependencies.auth import get_current_user
from app.models.user import Login

router = APIRouter()

# ─────────────────────────────────────────────────────────────
# NEW RESOURCE-BASED ENDPOINTS
# ─────────────────────────────────────────────────────────────

@router.get("/farms")
def list_farms_new(
    page: Optional[int] = Query(None, ge=1),
    skip: int = Query(0),
    limit: int = Query(50),
    db: Session = Depends(get_db)
):
    if page is not None:
        skip = (page - 1) * limit
    return FarmService.list_all_farms(db, skip, limit)

@router.get("/farms/{id}", response_model=FarmListingOut)
def get_farm_new(id: int, db: Session = Depends(get_db)):
    return FarmService.get_farm_listing(db, id)

@router.post("/farms", response_model=FarmListingOut)
def create_farm_new(
    data: FarmListingCreate,
    db: Session = Depends(get_db),
    current_user: Login = Depends(get_current_user)
):
    return FarmService.create_farm_listing(db, current_user.id, data)

# ─────────────────────────────────────────────────────────────
# LEGACY ENDPOINTS (BACKWARDS COMPATIBILITY)
# ─────────────────────────────────────────────────────────────

@router.get("/farmer/listing/{listing_id}", response_model=FarmListingOut)
def get_farm_listing_legacy(listing_id: int, db: Session = Depends(get_db)):
    return FarmService.get_farm_listing(db, listing_id)

@router.get("/farmer/check-availability/{listing_id}")
def check_farm_availability_legacy(
    listing_id: int,
    date_start: DateType = Query(...),
    date_end: DateType = Query(...),
    db: Session = Depends(get_db)
):
    return FarmService.check_farm_availability(db, listing_id, date_start, date_end)

@router.get("/farmer/list/{user_id}", response_model=List[FarmListingOut])
def get_farmer_listings_legacy(user_id: int, db: Session = Depends(get_db)):
    return FarmService.get_farmer_listings(db, user_id)

@router.post("/farmer/list/{user_id}", response_model=FarmListingOut)
def create_farm_listing_legacy(user_id: int, data: FarmListingCreate, db: Session = Depends(get_db)):
    return FarmService.create_farm_listing(db, user_id, data)

@router.put("/farmer/listing/{listing_id}", response_model=FarmListingOut)
def update_farm_listing_legacy(listing_id: int, data: FarmListingCreate, db: Session = Depends(get_db)):
    return FarmService.update_farm_listing(db, listing_id, data)

@router.delete("/farmer/listing/{listing_id}/{user_id}")
def delete_farm_listing_legacy(listing_id: int, user_id: int, db: Session = Depends(get_db)):
    return FarmService.delete_farm_listing(db, listing_id, user_id)

@router.get("/farmer/farm-listing")
def list_all_farms_legacy(skip: int = Query(0), limit: int = Query(50), db: Session = Depends(get_db)):
    return FarmService.list_all_farms(db, skip, limit)

@router.get("/farmer/search/{user_id}")
def search_farmers_legacy(
    user_id: int,
    query: Optional[str] = Query(None),
    date_start: Optional[DateType] = Query(None),
    date_end: Optional[DateType] = Query(None),
    time_slot: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    return FarmService.search_farms(db, user_id, query, date_start, date_end, time_slot)
