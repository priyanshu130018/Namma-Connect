from fastapi import APIRouter, Depends, Query, Header, BackgroundTasks
from sqlalchemy.orm import Session
from typing import Optional

from app.core.database import get_db
from app.services.auth_service import AuthService
from app.schemas.user import RegisterRequest, LoginRequest, ChangePasswordRequest, TokenResponse
from app.dependencies.auth import get_current_user
from app.models.user import Login
from app.dependencies.rate_limit import login_limiter

router = APIRouter()

# ─────────────────────────────────────────────────────────────
# NEW RESOURCE-BASED ENDPOINTS
# ─────────────────────────────────────────────────────────────

@router.post("/auth/register", response_model=TokenResponse)
def register_new(req: RegisterRequest, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    return AuthService.register(db, req, background_tasks)

@router.post("/auth/login", response_model=TokenResponse)
def login_new(req: LoginRequest, db: Session = Depends(get_db), _rate_limit = Depends(login_limiter)):
    return AuthService.login(db, req)

@router.post("/auth/change-password")
def change_password_new(req: ChangePasswordRequest, db: Session = Depends(get_db)):
    return AuthService.change_password(db, req)

# ─────────────────────────────────────────────────────────────
# LEGACY ENDPOINTS (BACKWARDS COMPATIBILITY)
# ─────────────────────────────────────────────────────────────

@router.post("/register", response_model=TokenResponse)
def register_legacy(req: RegisterRequest, background_tasks: BackgroundTasks, db: Session = Depends(get_db)):
    return AuthService.register(db, req, background_tasks)

@router.post("/login", response_model=TokenResponse)
def login_legacy(req: LoginRequest, db: Session = Depends(get_db), _rate_limit = Depends(login_limiter)):
    return AuthService.login(db, req)

@router.post("/google", response_model=TokenResponse)
def google_login_legacy(credential: str = Query(...), db: Session = Depends(get_db)):
    return AuthService.google_login(db, credential)

@router.get("/me")
def me_legacy(token: str, db: Session = Depends(get_db)):
    # Legacy me uses query parameter token
    from app.core.security import decode_token
    try:
        payload = decode_token(token)
        user_id = int(payload["sub"])
    except Exception:
        from fastapi import HTTPException
        raise HTTPException(status_code=401, detail="Invalid token")

    login_obj = db.query(Login).filter(Login.id == user_id).first()
    if not login_obj:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="User not found")

    return {"user_id": user_id, "email": login_obj.email, "role": login_obj.role}

@router.post("/change-password")
def change_password_legacy(req: ChangePasswordRequest, db: Session = Depends(get_db)):
    return AuthService.change_password(db, req)

@router.post("/change-password/{user_id}")
def change_password_auth_legacy(user_id: int, req: ChangePasswordRequest, db: Session = Depends(get_db)):
    return AuthService.change_password_authenticated(db, user_id, req)

@router.delete("/delete-account/{user_id}")
def delete_account_legacy(user_id: int, db: Session = Depends(get_db)):
    return AuthService.delete_account(db, user_id)
