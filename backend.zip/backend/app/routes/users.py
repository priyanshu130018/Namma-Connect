from fastapi import APIRouter, Depends, Query, Header, HTTPException
from sqlalchemy.orm import Session
from typing import Optional, List

from app.core.database import get_db
from app.services.user_service import UserService
from app.schemas import (
    FarmerProfileOut, FarmerRegisterRequest, TouristOut, TouristUpdate,
    CreatorOut, CreatorRegisterRequest, ContactCreate, ContactOut,
    MessageCreate, MessageOut, NotificationOut
)
from app.dependencies.auth import get_current_user
from app.models.user import Login

router = APIRouter()

# ─────────────────────────────────────────────────────────────
# FARMER PROFILE ENDPOINTS (LEGACY & NEW)
# ─────────────────────────────────────────────────────────────

@router.post("/services/farmer/register/{user_id}", response_model=FarmerProfileOut)
def register_farmer(user_id: int, data: FarmerRegisterRequest, db: Session = Depends(get_db)):
    return UserService.register_farmer(db, data, user_id)

@router.get("/farmer/profile/{user_id}", response_model=FarmerProfileOut)
def get_farmer_profile(user_id: int, db: Session = Depends(get_db)):
    return UserService.get_farmer_profile(db, user_id)

@router.get("/farmer/by-profile/{farmer_id}", response_model=FarmerProfileOut)
def get_farmer_by_profile_id(farmer_id: int, db: Session = Depends(get_db)):
    return UserService.get_farmer_by_profile_id(db, farmer_id)

@router.put("/farmer/profile/{user_id}", response_model=FarmerProfileOut)
def update_farmer_profile(user_id: int, data: Optional[dict] = None, db: Session = Depends(get_db)):
    return UserService.update_farmer_profile(db, user_id, data)

@router.get("/farmer/settings/{user_id}")
def get_farmer_settings(user_id: int, db: Session = Depends(get_db)):
    return {"user_id": user_id, "availability": "open", "instant_booking": True}

# ─────────────────────────────────────────────────────────────
# TOURIST PROFILE ENDPOINTS (LEGACY & NEW)
# ─────────────────────────────────────────────────────────────

@router.get("/tourist/profile/{user_id}", response_model=TouristOut)
def get_tourist_profile(user_id: int, db: Session = Depends(get_db)):
    return UserService.get_tourist_profile(db, user_id)

@router.put("/tourist/profile/{user_id}", response_model=TouristOut)
def update_tourist_profile(user_id: int, data: TouristUpdate, db: Session = Depends(get_db)):
    return UserService.update_tourist_profile(db, user_id, data)

@router.get("/tourist/wishlist/{user_id}")
def get_wishlist(user_id: int, db: Session = Depends(get_db)):
    return UserService.get_wishlist(db, user_id)

@router.put("/tourist/wishlist/{user_id}")
def update_wishlist(user_id: int, wishlist: str = Query(...), db: Session = Depends(get_db)):
    return UserService.update_wishlist(db, user_id, wishlist)

@router.get("/tourist/settings/{user_id}")
def get_tourist_settings(user_id: int, db: Session = Depends(get_db)):
    return {"user_id": user_id, "currency": "INR", "language": "en"}

# ─────────────────────────────────────────────────────────────
# CREATOR PROFILE ENDPOINTS (LEGACY & NEW)
# ─────────────────────────────────────────────────────────────

@router.post("/services/creator/register/{user_id}", response_model=CreatorOut)
def register_creator(user_id: int, data: CreatorRegisterRequest, db: Session = Depends(get_db)):
    return UserService.register_creator(db, data, user_id)

@router.get("/creator/profile/{user_id}", response_model=CreatorOut)
def get_creator_profile(user_id: int, db: Session = Depends(get_db)):
    return UserService.get_creator_profile(db, user_id)

@router.put("/creator/profile/{user_id}", response_model=CreatorOut)
def update_creator_profile(user_id: int, data: CreatorRegisterRequest, db: Session = Depends(get_db)):
    return UserService.update_creator_profile(db, user_id, data)

@router.get("/creator/settings/{user_id}")
def get_creator_settings(user_id: int, db: Session = Depends(get_db)):
    return {"user_id": user_id, "notifications": True, "privacy": "public"}

@router.get("/creator/{creator_id}", response_model=CreatorOut)
def get_creator_by_id(creator_id: int, db: Session = Depends(get_db)):
    return UserService.get_creator_by_id(db, creator_id)

# ─────────────────────────────────────────────────────────────
# MESSAGES ENDPOINTS (LEGACY & NEW)
# ─────────────────────────────────────────────────────────────

@router.get("/messages")
def get_messages(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    from app.core.security import decode_token
    if not authorization or not authorization.startswith("Bearer "):
        return []
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
        user_id = int(payload.get("sub", 0))
    except Exception:
        return []

    return UserService.get_messages(db, user_id)

@router.post("/messages")
def send_message(
    data: MessageCreate,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    from app.core.security import decode_token
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
        user_id = int(payload.get("sub", 0))
    except Exception:
        raise HTTPException(status_code=401, detail="Authentication required")

    return UserService.send_message(db, user_id, data)

# ─────────────────────────────────────────────────────────────
# NOTIFICATIONS ENDPOINTS (LEGACY & NEW)
# ─────────────────────────────────────────────────────────────

@router.get("/notifications")
def get_notifications(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    from app.core.security import decode_token
    if not authorization or not authorization.startswith("Bearer "):
        return []
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
        user_id = int(payload.get("sub", 0))
    except Exception:
        return []

    return UserService.get_notifications(db, user_id)

@router.post("/notifications/{notification_id}/read")
def mark_notification_read(
    notification_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    from app.core.security import decode_token
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
        user_id = int(payload.get("sub", 0))
    except Exception:
        raise HTTPException(status_code=401, detail="Authentication required")

    return UserService.mark_notification_read(db, user_id, notification_id)

@router.post("/notifications/read-all")
def mark_all_notifications_read(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    from app.core.security import decode_token
    if not authorization or not authorization.startswith("Bearer "):
        return {"success": True}
    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_token(token)
        user_id = int(payload.get("sub", 0))
    except Exception:
        return {"success": True}

    return UserService.mark_all_notifications_read(db, user_id)

# ─────────────────────────────────────────────────────────────
# CONTACT SUBMISSION ENDPOINTS (LEGACY & NEW)
# ─────────────────────────────────────────────────────────────

@router.post("/contact/submit", response_model=ContactOut)
def submit_contact(data: ContactCreate, db: Session = Depends(get_db)):
    return UserService.submit_contact(db, data)
