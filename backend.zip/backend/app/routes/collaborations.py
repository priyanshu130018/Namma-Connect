from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.services.booking_service import BookingService
from app.schemas.booking import BookingCreate, BookingOut, BookingStatusUpdate
from app.dependencies.auth import get_current_user
from app.models.user import Login

router = APIRouter()

# ─────────────────────────────────────────────────────────────
# NEW RESOURCE-BASED ENDPOINTS
# ─────────────────────────────────────────────────────────────

@router.get("/collaborations")
def get_collaborations_new(
    db: Session = Depends(get_db),
    current_user: Login = Depends(get_current_user)
):
    return BookingService.get_collaborations(db, current_user.id)

@router.post("/collaborations", response_model=BookingOut)
def create_collaboration_new(
    data: BookingCreate,
    db: Session = Depends(get_db),
    current_user: Login = Depends(get_current_user)
):
    # Ensure it's a creator booking
    data.booking_type = "creator"
    return BookingService.create_booking(db, data, current_user.id)

# ─────────────────────────────────────────────────────────────
# LEGACY ENDPOINTS (BACKWARDS COMPATIBILITY)
# ─────────────────────────────────────────────────────────────

@router.get("/collaborations/{user_id}")
def get_collaborations_legacy(user_id: int, db: Session = Depends(get_db)):
    return BookingService.get_collaborations(db, user_id)

@router.put("/collaborations/status/{booking_id}/{user_id}")
def update_collab_status_legacy(
    booking_id: int,
    user_id: int,
    data: dict = Body(...),
    db: Session = Depends(get_db)
):
    status_str = data.get("status")
    return BookingService.update_collab_status(db, booking_id, user_id, status_str)
