from fastapi import APIRouter, Request, Header, HTTPException, Depends
from sqlalchemy.orm import Session
import json
import hmac
import hashlib
import os

from app.core.database import get_db
from app.core.config import settings
from app.core.logger import logger
from app.models.booking import Booking
from app.models.payment import Payment
from app.services.email_service import EmailService

router = APIRouter()

@router.post("/webhook/razorpay")
async def razorpay_webhook(
    request: Request,
    x_razorpay_signature: str = Header(None),
    db: Session = Depends(get_db)
):
    raw_body = await request.body()
    
    secret = os.getenv("RAZORPAY_WEBHOOK_SECRET") or settings.RAZORPAY_SECRET
    if secret and x_razorpay_signature:
        expected_sig = hmac.new(
            secret.encode("utf-8"),
            raw_body,
            hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(expected_sig, x_razorpay_signature):
            logger.warning("Invalid webhook signature received")
            raise HTTPException(status_code=400, detail="Signature verification failed")

    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    event = payload.get("event")
    logger.info(f"Received Razorpay Webhook Event: {event}")

    event_payload = payload.get("payload", {})
    payment_entity = event_payload.get("payment", {}).get("entity", {})

    booking_id = payment_entity.get("notes", {}).get("booking_id")
    if not booking_id:
        receipt = payment_entity.get("receipt")
        if receipt and "_" in receipt:
            try:
                booking_id = int(receipt.split("_")[-1])
            except ValueError:
                pass

    if not booking_id:
        logger.warning("Webhook received without booking_id")
        return {"success": False, "message": "booking_id not resolved"}

    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        logger.warning(f"Webhook booking not found: {booking_id}")
        return {"success": False, "message": "Booking not found"}

    if booking.payment_status == "paid":
        logger.info(f"Payment already processed for booking {booking_id}")
        return {"success": True, "message": "Payment already processed"}

    if event == "payment.captured":
        booking.payment_status = "paid"
        
        existing_payment = db.query(Payment).filter(Payment.booking_id == booking.id).first()
        if not existing_payment:
            user_id = booking.tourist.user_id if booking.tourist else booking.tourist_id
            payment = Payment(
                booking_id=booking.id,
                user_id=user_id,
                amount=booking.total_price,
                method="razorpay",
                status="paid"
            )
            db.add(payment)
        db.commit()

        email = None
        name = "Guest"
        if booking.tourist:
            email = booking.tourist.email or (booking.tourist.user.email if booking.tourist.user else None)
            name = booking.tourist.name
        
        if email:
            subject = "Booking Paid Successfully"
            body = f"Hi {name}, we verified your payment for booking ID {booking.id}. Thanks for traveling with us!"
            EmailService.send_email(email, subject, body)

        logger.info(f"Payment captured successfully for booking {booking_id}")

    elif event == "payment.failed":
        booking.payment_status = "failed"
        db.commit()
        logger.info(f"Payment failed for booking {booking_id}")

    return {"success": True}
