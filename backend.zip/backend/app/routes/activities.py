from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List

from app.core.database import get_db
from app.models.activity import Activity
from app.schemas.farm import ActivityCreate, ActivityOut

router = APIRouter()

@router.get("/activities", response_model=List[ActivityOut])
def get_activities(skip: int = Query(0), limit: int = Query(50), db: Session = Depends(get_db)):
    return db.query(Activity).offset(skip).limit(limit).all()

@router.post("/activities", response_model=ActivityOut)
def create_activity(data: ActivityCreate, db: Session = Depends(get_db)):
    act = Activity(
        farm_id=data.farm_id,
        title=data.title,
        description=data.description,
        location=data.location,
        price=data.price,
        duration=data.duration,
        category=data.category,
        status=data.status or "active"
    )
    db.add(act)
    db.commit()
    db.refresh(act)
    return act
