from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, Dict, Any, List

from app.core.database import get_db
from app.models.farm import FarmListing
from app.models.user import Creator
from app.ai.recommender import recommender_agent
from app.ai.chatbot import trip_planner_agent

router = APIRouter()

class RecommendRequest(BaseModel):
    query: str
    item_type: str = "farm" # farm or creator

class ChatRequest(BaseModel):
    prompt: str
    session_state: Optional[Dict[str, Any]] = None

# ─────────────────────────────────────────────────────────────
# NEW RESOURCE-BASED ENDPOINTS
# ─────────────────────────────────────────────────────────────

@router.post("/ai/recommend")
def ai_recommend_new(req: RecommendRequest, db: Session = Depends(get_db)):
    if req.item_type == "creator":
        items = db.query(Creator).all()
    else:
        items = db.query(FarmListing).filter(FarmListing.is_active == True).all()
        
    try:
        results = recommender_agent.get_recommendations(req.query, items, item_type=req.item_type)
    except Exception as e:
        logger.error(f"Recommender agent error, using keyword fallback: {str(e)}")
        results = []
        q = req.query.lower()
        for item in items:
            score = 0.50
            if req.item_type == "creator":
                name = item.name or ""
                niche = item.niche or ""
                if q in name.lower() or q in niche.lower():
                    score = 0.85
                results.append({"item": item, "matchScore": score})
            else:
                name = item.farm_name or ""
                crops = item.crop_types or ""
                if q in name.lower() or q in crops.lower():
                    score = 0.85
                results.append({"item": item, "matchScore": score})
        results.sort(key=lambda x: x["matchScore"], reverse=True)
    
    output = []
    for r in results:
        item = r["item"]
        if req.item_type == "creator":
            output.append({
                "id": item.id,
                "name": item.name,
                "location": f"{item.city}, {item.state}" if item.city else item.state,
                "niche": item.niche,
                "matchScore": r["matchScore"]
            })
        else:
            output.append({
                "id": item.id,
                "name": item.farm_name,
                "location": f"{item.city}, {item.state}" if item.city else item.state,
                "crop_types": item.crop_types,
                "matchScore": r["matchScore"]
            })
    return {"success": True, "data": output}

@router.post("/ai/chat")
def ai_chat_new(req: ChatRequest, db: Session = Depends(get_db)):
    try:
        farms = db.query(FarmListing).filter(FarmListing.is_active == True).all()
        creators = db.query(Creator).all()
        
        result = trip_planner_agent.get_trip_suggestion(
            prompt=req.prompt,
            farm_listings=farms,
            creators=creators,
            session_state=req.session_state
        )
        return {"success": True, "data": result}
    except Exception as e:
        logger.warning(f"AI Chat model failed, using rule-based suggestion fallback: {str(e)}")
        fallback_response = {
            "response": f"I received your request: '{req.prompt}'. While my AI brain is resting, I suggest exploring some of our beautiful local farm stays!",
            "suggestions": []
        }
        try:
            farms = db.query(FarmListing).filter(FarmListing.is_active == True).limit(2).all()
            for f in farms:
                fallback_response["suggestions"].append({
                    "id": f.id,
                    "name": f.farm_name,
                    "location": f"{f.city}, {f.state}" if f.city else f.state,
                    "score": 0.75
                })
        except Exception:
            pass
        return {"success": True, "data": fallback_response}

# ─────────────────────────────────────────────────────────────
# LEGACY ENDPOINTS (BACKWARDS COMPATIBILITY)
# ─────────────────────────────────────────────────────────────

@router.post("/tourist/ai-planner/{user_id}")
def ai_planner_legacy(preferences: str = Body(..., embed=True), days: int = Body(3, embed=True)):
    return {
        "itinerary": [
            {"day": i+1, "plan": f"Visit local farm and enjoy {preferences} activities"}
            for i in range(days)
        ],
        "suggestion": "We recommend the Coffee Harvest Tour based on your interests!"
    }

@router.api_route("/farmer/trip-planner/{user_id}", methods=["GET", "POST"])
def plan_trip_farmer_legacy(user_id: int, prompt: str = Body(..., embed=True), db: Session = Depends(get_db)):
    farms = db.query(FarmListing).filter(FarmListing.is_active == True).all()
    result = trip_planner_agent.get_trip_suggestion(prompt, farms)
    
    simplified_suggestions = []
    for s in result["suggestions"]:
        simplified_suggestions.append({
            "id": s["id"],
            "name": s["name"],
            "location": s["location"],
            "matchScore": s["score"]
        })
    
    return {
        "response": result["response"],
        "suggestions": simplified_suggestions
    }

@router.api_route("/creator/trip-planner/{user_id}", methods=["GET", "POST"])
def plan_trip_creator_legacy(user_id: int, prompt: str = Body(..., embed=True), db: Session = Depends(get_db)):
    creator = db.query(Creator).filter(Creator.user_id == user_id).first()
    if not creator:
        raise HTTPException(status_code=404, detail="Creator not found")
    farms = db.query(FarmListing).filter(FarmListing.is_active == True).all()
    result = trip_planner_agent.get_trip_suggestion(prompt, farms)
    
    simplified_suggestions = []
    for s in result["suggestions"]:
        simplified_suggestions.append({
            "id": s["id"],
            "name": s["name"],
            "location": s["location"],
            "matchScore": s["score"]
        })
    
    return {
        "response": result["response"],
        "suggestions": simplified_suggestions
    }
