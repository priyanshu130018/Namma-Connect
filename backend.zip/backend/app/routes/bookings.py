from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from typing import Optional, List
from datetime import date as DateType

from app.core.database import get_db
from app.services.booking_service import BookingService
from app.schemas.booking import BookingCreate, BookingOut, BookingStatusUpdate
from app.dependencies.auth import get_current_user
from app.models.user import Login

router = APIRouter()

# ─────────────────────────────────────────────────────────────
# NEW RESOURCE-BASED ENDPOINTS
# ─────────────────────────────────────────────────────────────

@router.post("/bookings", response_model=BookingOut)
def create_booking_new(
    data: BookingCreate,
    db: Session = Depends(get_db),
    current_user: Login = Depends(get_current_user)
):
    return BookingService.create_booking(db, data, current_user.id)

@router.get("/bookings", response_model=List[BookingOut])
def get_bookings_new(
    status: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: Login = Depends(get_current_user)
):
    return BookingService.get_tourist_bookings(db, current_user.id, status)

@router.patch("/bookings/{id}")
def update_booking_status_new(
    id: int,
    data: BookingStatusUpdate,
    db: Session = Depends(get_db)
):
    return BookingService.update_booking_status(db, id, data)

# ─────────────────────────────────────────────────────────────
# LEGACY ENDPOINTS (BACKWARDS COMPATIBILITY)
# ─────────────────────────────────────────────────────────────

@router.post("/tourist/booking/{user_id}", response_model=BookingOut)
def create_booking_legacy(user_id: int, data: BookingCreate, db: Session = Depends(get_db)):
    return BookingService.create_booking(db, data, user_id)

@router.get("/tourist/bookings/{user_id}", response_model=List[BookingOut])
def get_bookings_legacy(user_id: int, status: Optional[str] = Query(None), db: Session = Depends(get_db)):
    return BookingService.get_tourist_bookings(db, user_id, status)

@router.delete("/tourist/booking/{booking_id}/{user_id}")
def cancel_booking_legacy(booking_id: int, user_id: int, db: Session = Depends(get_db)):
    return BookingService.cancel_booking(db, booking_id, user_id)

@router.get("/farmer/bookings/{user_id}")
def get_farmer_bookings_legacy(user_id: int, db: Session = Depends(get_db)):
    return BookingService.get_farmer_bookings(db, user_id)

@router.put("/farmer/booking/{booking_id}/status/{user_id}")
def update_farmer_booking_status_legacy(
    booking_id: int,
    user_id: int,
    data: BookingStatusUpdate,
    db: Session = Depends(get_db)
):
    return BookingService.update_farmer_booking_status(db, booking_id, user_id, data)

@router.get("/creator/bookings/{user_id}")
def get_creator_bookings_legacy(user_id: int, db: Session = Depends(get_db)):
    return BookingService.get_creator_bookings(db, user_id)

@router.put("/creator/booking/{booking_id}/status/{user_id}")
def update_creator_booking_status_legacy(
    booking_id: int,
    user_id: int,
    data: BookingStatusUpdate,
    db: Session = Depends(get_db)
):
    return BookingService.update_creator_booking_status(db, booking_id, user_id, data)

@router.put("/booking/{booking_id}/status")
def update_booking_status_legacy(
    booking_id: int,
    data: BookingStatusUpdate,
    db: Session = Depends(get_db)
):
    return BookingService.update_booking_status(db, booking_id, data)

@router.get("/creator/check-availability/{creator_id}")
def check_creator_availability_legacy(
    creator_id: int,
    date_start: DateType = Query(...),
    date_end: DateType = Query(...),
    db: Session = Depends(get_db)
):
    return BookingService.check_creator_availability(db, creator_id, date_start, date_end)
