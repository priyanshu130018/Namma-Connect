from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

from app.core.database import get_db
from app.services.payment_service import PaymentService
from app.schemas.payment import PaymentCreate, PaymentOut
from app.dependencies.auth import get_current_user
from app.models.user import Login
from app.dependencies.rate_limit import payment_limiter

router = APIRouter()

class OrderCreateRequest(BaseModel):
    booking_id: int

class PaymentVerifyRequest(BaseModel):
    booking_id: int
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str

@router.post("/payments/create-order")
def create_payment_order(req: OrderCreateRequest, db: Session = Depends(get_db), _rate_limit = Depends(payment_limiter)):
    return PaymentService.create_order(req.booking_id, db)

@router.post("/payments/verify")
def verify_payment_order(req: PaymentVerifyRequest, background_tasks: BackgroundTasks, db: Session = Depends(get_db), _rate_limit = Depends(payment_limiter)):
    success = PaymentService.verify_payment(
        req.booking_id,
        req.razorpay_order_id,
        req.razorpay_payment_id,
        req.razorpay_signature,
        db,
        background_tasks
    )
    return {"success": success}

@router.post("/payments", response_model=PaymentOut)
def create_payment(
    data: PaymentCreate,
    db: Session = Depends(get_db),
    current_user: Login = Depends(get_current_user)
):
    return PaymentService.create_payment(db, data, current_user.id)

@router.get("/payments/{user_id}", response_model=List[PaymentOut])
def get_payments(user_id: int, db: Session = Depends(get_db)):
    return PaymentService.get_payments(db, user_id)
