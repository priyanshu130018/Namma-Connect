from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime
from decimal import Decimal
from app.schemas.user import FarmerProfileCreate

class FarmListingBase(BaseModel):
    farm_name: str = Field(..., min_length=2)
    description: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    mobile: Optional[str] = Field(None, min_length=10, max_length=10)
    email: Optional[EmailStr] = None
    crop_types: Optional[str] = None
    farm_photo: Optional[str] = None
    stay_available: Optional[str] = None
    transport_available: Optional[str] = None
    activities: Optional[str] = None
    price_per_night: Optional[Decimal] = Field(None, ge=0)
    latitude: Optional[Decimal] = None
    longitude: Optional[Decimal] = None
    is_active: bool = True

class FarmListingCreate(FarmListingBase):
    pass

class FarmListingOut(FarmListingBase):
    id: int
    farmer_id: int
    user_id: Optional[int] = None
    latitude: Optional[Decimal] = None
    longitude: Optional[Decimal] = None
    created_at: Optional[datetime]

    class Config:
        from_attributes = True


class FarmerRegisterRequest(BaseModel):
    profile: FarmerProfileCreate
    listing: Optional[FarmListingCreate] = None


class ActivityCreate(BaseModel):
    farm_id: Optional[int] = None
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    price: Decimal = Field(0.00, ge=0)
    duration: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = "active"

class ActivityOut(BaseModel):
    id: int
    farm_id: Optional[int] = None
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    price: Decimal
    duration: Optional[str] = None
    category: Optional[str] = None
    status: str
    created_at: Optional[datetime]

    class Config:
        from_attributes = True
