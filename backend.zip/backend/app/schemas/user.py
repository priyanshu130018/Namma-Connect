from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import datetime

class RegisterRequest(BaseModel):
    full_name: str = Field(..., min_length=2)
    email: EmailStr
    password: str = Field(..., min_length=6)
    role: Optional[str] = "tourist" # tourist, creator, farmer
    mobile: Optional[str] = Field(None, min_length=10, max_length=10)

    @validator("mobile")
    def validate_mobile(cls, v):
        if v is not None and not v.isdigit():
            raise ValueError("Mobile number must contain only digits")
        return v


class LoginRequest(BaseModel):
    identifier: str # email
    password: str


class ChangePasswordRequest(BaseModel):
    identifier: str # email
    new_password: str = Field(..., min_length=6)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    profile_id: int # Profile ID (tourist_id, creator_id, or farmer_id)
    user_id: int # Login table ID
    role: str
    name: str
    email: Optional[EmailStr] = None
    mobile: Optional[str] = Field(None, min_length=10, max_length=10)


class TouristBase(BaseModel):
    name: str = Field(..., min_length=2)
    age: Optional[int] = Field(None, ge=0)
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = "India"
    postal_code: Optional[str] = None
    mobile: Optional[str] = Field(None, min_length=10, max_length=10)
    email: Optional[EmailStr] = None
    aadhaar_no: Optional[str] = Field(None, min_length=12, max_length=12)
    bio: Optional[str] = None
    wishlist: Optional[str] = None

class TouristUpdate(TouristBase):
    name: Optional[str] = Field(None, min_length=2)

class TouristOut(TouristBase):
    id: int
    user_id: int
    is_verified: bool
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class CreatorBase(BaseModel):
    name: str = Field(..., min_length=2)
    age: Optional[int] = Field(None, ge=0)
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = "India"
    postal_code: Optional[str] = None
    mobile: Optional[str] = Field(None, min_length=10, max_length=10)
    email: Optional[EmailStr] = None
    aadhaar_no: Optional[str] = Field(None, min_length=12, max_length=12)
    niche: Optional[str] = None
    portfolio: Optional[str] = None
    instagram: Optional[str] = None
    youtube: Optional[str] = None
    has_work_experience: bool = False
    bio: Optional[str] = None
    rate: Optional[float] = Field(0.00, ge=0)

class CreatorRegisterRequest(CreatorBase):
    pass

class CreatorOut(CreatorBase):
    id: int
    user_id: int
    is_verified: bool
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class FarmerBase(BaseModel):
    name: str = Field(..., min_length=2)
    age: Optional[int] = Field(None, ge=0)
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = "India"
    postal_code: Optional[str] = None
    mobile: Optional[str] = Field(None, min_length=10, max_length=10)
    email: Optional[EmailStr] = None
    aadhaar_no: Optional[str] = Field(None, min_length=12, max_length=12)
    identity_proof: Optional[str] = None

class FarmerProfileCreate(FarmerBase):
    pass

class FarmerProfileOut(FarmerBase):
    id: int
    user_id: int
    is_verified: bool
    created_at: Optional[datetime]
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class UserOut(BaseModel):
    id: int
    full_name: str
    email: EmailStr
    role: str
    mobile: Optional[str]
    is_active: bool
    created_at: Optional[datetime]

    class Config:
        from_attributes = True


class ContactCreate(BaseModel):
    name: str = Field(..., min_length=2)
    email: EmailStr
    topic: Optional[str] = None
    message: Optional[str] = None


class ContactOut(ContactCreate):
    id: int
    created_at: Optional[datetime]

    class Config:
        from_attributes = True


class NotificationOut(BaseModel):
    id: int
    user_id: int
    title: str
    body: Optional[str] = None
    category: Optional[str] = None
    type: Optional[str] = None
    is_read: bool
    created_at: Optional[datetime]

    class Config:
        from_attributes = True


class MessageCreate(BaseModel):
    receiver_id: int
    content: str


class MessageOut(BaseModel):
    id: int
    sender_id: int
    receiver_id: int
    content: str
    is_read: bool
    created_at: Optional[datetime]

    class Config:
        from_attributes = True
