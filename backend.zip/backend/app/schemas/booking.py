from pydantic import BaseModel, Field, validator
from typing import Optional
from datetime import datetime, date as DateType
from decimal import Decimal

class BookingCreate(BaseModel):
    tourist_id: Optional[int] = None
    booking_type: str  # farm, creator
    farm_id: Optional[int] = None
    creator_id: Optional[int] = None
    check_in: DateType
    check_out: DateType

    adults: int = Field(1, ge=1)
    children: int = Field(0, ge=0)

    total_price: Decimal = Field(0.00, ge=0)
    collab_note: Optional[str] = None

    @validator("check_out")
    def validate_dates(cls, v, values):
        # In pydantic v2, values can be a ValidationInfo object or dict.
        # To be fully compatible with both v1 and v2:
        check_in = None
        if hasattr(values, "data"):
            check_in = values.data.get("check_in")
        elif isinstance(values, dict):
            check_in = values.get("check_in")
        else:
            # Fallback
            try:
                check_in = values.check_in
            except Exception:
                pass
        
        if check_in and v <= check_in:
            raise ValueError("check_out must be after check_in")
        return v

class BookingOut(BaseModel):
    id: int
    tourist_id: int
    booking_type: str
    farm_id: Optional[int] = None
    creator_id: Optional[int] = None
    check_in: DateType
    check_out: DateType

    adults: int
    children: int
    guests: int

    total_price: Decimal
    collab_note: Optional[str] = None
    status: str
    payment_status: Optional[str] = "unpaid"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    # Fields added for frontend convenience (not in DB)
    item_name: Optional[str] = None
    item_emoji: Optional[str] = None
    region: Optional[str] = None
    tourist_name: Optional[str] = None

    class Config:
        from_attributes = True


class BookingStatusUpdate(BaseModel):
    status: str
