from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from decimal import Decimal

class PaymentCreate(BaseModel):
    booking_id: int
    amount: Decimal
    method: str

class PaymentOut(BaseModel):
    id: int
    booking_id: int
    user_id: int
    amount: Decimal
    method: str
    status: str
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
